#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""Creating a dictionary bl_info that contains metadata 
(data that provides information) about the addon:"""

bl_info = {
    "name" : "FOSSEE_Blender_Addon",
    "author" : "Swaroop_R",
    "version" : (1, 0),
    "blender" : (4, 4, 0),
    "location" : "View3D > Sidebar > Addon_Panel",
    "warning" : "",
    "doc_url":"",
    "category":"Add Object"
    }
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import bpy
"""This will allow access to Blender's Python application programming 
interface (API) which I can use to interact with and manipulate almost
every aspect of Blender programmatically."""
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import bmesh
"""
BMesh is a mesh data structure which enables complex and flexible modeling.
"""
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
from mathutils import Vector
"""
To be used in positioning the merged mesh.
"""
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Creating a class MyAddonSettings that defines the Addon's properties:
class MyAddonSettings(bpy.types.PropertyGroup):
     # Adding properties of the input:
     input_n : bpy.props.IntProperty(
          name = "N Value",
          description = "Number of cubes you want to create (0-20)",
          default = 5
     )

"""
NOTE: 
PropertyGroup needs a "host" (like Scene) to exist.
PointerProperty assigns the host and manages the lifecycle. This is done at the last of this entire code.
"""
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
Operators are actions that perform specific tasks when triggered—like running a tool, 
modifying objects, or executing scripts.
"""
# Creating an operator class "ShowError" that will show a popup for unacceptable input numbers:
class ShowError(bpy.types.Operator):

     # Assigining a unique ID for the class:
     bl_idname = "object.show_error_popup"
     """This means the operator can be called in Blender via: bpy.ops.object.show_error_popup()"""

    # Writing a human readable label:
     bl_label = "Error"

     # Defining a string property that will store the error message to be displayed:
     message: bpy.props.StringProperty()

     # execute() is a required method for operators, but in this case it will return 'FINISHED'.
     """
     One must include an execute() method in an operator class—even 
     if it's empty—because it's a required method for all Blender operators.
     If omitted, Blender will raise an error when registering the operator.
     """
     def execute(self,context):
          return {'FINISHED'}
     
     # Defining a method that is called when the operator is triggered.
     # invoke() will trigger the popup:
     #         - This method is called when the operator is executed:
                          # e.g., via bpy.ops.object.show_error_popup('INVOKE_DEFAULT')
     #         - The method uses 'ainvoke_popup' to show a popup dialog
     def invoke(self,context,event):
          return context.window_manager.invoke_popup(self,width = 400)
     """
     NOTE: 
     - The Blender's operator execution workflow follows a specific sequence for flexibility and user interaction.
     - When an operator is triggered, invoke() runs first always. execute() runs only if invoke() allows it.
     """
     # Defining the UI layout of the popup:
     def draw(self,context):            # draw() runs automatically in an operator only if the operator explicitly opens a UI
          layout = self.layout
          row = layout.row()
          row.label(text='Error!',icon='ERROR')
          layout.label(text = self.message)
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
Creating an operator class "Show_Overlapp_Error" that will show a popup if the cubes are overlapping.
"""
class Show_Overlapp_Error(bpy.types.Operator):
     
     # Assigining a unique ID for the class:
     bl_idname = "object.show_overlapp_error_popup"
     """This means the operator can be called in Blender via: bpy.ops.object.show_overlapp_error_popup()"""

     # Writing a human readable label:
     bl_label = "Attention!"

     # Defining a string property that will store the error message to be displayed:
     message: bpy.props.StringProperty()

     # execute() is a required method for operators, but in this case it will return 'FINISHED'.
     """
     One must include an execute() method in an operator class—even 
     if it's empty—because it's a required method for all Blender operators.
     If omitted, Blender will raise an error when registering the operator.
     """
     def execute(self,context):
          return {'FINISHED'}
     
     # Defining a method that is called when the operator is triggered.
     # invoke() will trigger the popup:
     #         - This method is called when the operator is executed:
                          # e.g., via bpy.ops.object.show_error_popup('INVOKE_DEFAULT')
     #         - The method uses 'ainvoke_popup' to show a popup dialog
     def invoke(self,context,event):
          return context.window_manager.invoke_popup(self,width = 550)
     """
     NOTE: 
     - The Blender's operator execution workflow follows a specific sequence for flexibility and user interaction.
     - When an operator is triggered, invoke() runs first always. execute() runs only if invoke() allows it.
     """
     # Defining the UI layout of the popup:
     def draw(self,context):            # draw() runs automatically in an operator only if the operator explicitly opens a UI
          layout = self.layout
          row = layout.row()
          row.label(text='Attention!',icon='ERROR')
          layout.label(text = self.message)



#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
Creating an operator class 'Operator_1' which will define operations to perform using the input for N.
"""
class Operator_1(bpy.types.Operator):
    
     # Defining a unique ID for the class:
     bl_idname = "object.operator_1" 
     """This means the operator can be called in Blender 
     via: bpy.ops.object.operator_1()"""

     # Writing a human readable label:
     bl_label = "Distribute Cubes"

     # Defining the operator behavior:
     bl_options = {'REGISTER','UNDO'}
     """
     'REGISTER' - 
          Makes the operator appear in Blender's UI search (F3 menu) and keymap preferences.
          Without this, users couldn't assign shortcuts to my operator.

     'UNDO' - 
          Allows users to undo the operator's action with Ctrl+Z.
     """

     # Writing a description for the operator:
     bl_description = 'Click to create cubes.'

     collection_counter = 0      # A counter for keeping track of the collection count

     # A method for creating and distributing cubes.
     def execute(self, context):
               # Accessing the addon's custom properties from the current scene:
               settings = context.scene.my_addon_settings    

               # Accessing the user-defined input
               N = settings.input_n
     
               if N == 0:
                    return {'FINISHED'}  # Exit if no cubes are requested.
               
               # Defining the size of each cube (1.0 Blender unit)
               cube_size = 1.0

               # Accessing the current location of 3D cursor 
               cursor_location = context.scene.cursor.location

               # Incrementing the counter
               Operator_1.collection_counter += 1

               # Creating a new collection with a unique name "Cubes_{#iteration}"
               # Storing the collection as an instance variable (self.collection) so it can be accessed by other methods in the class:
               self.new_collection = bpy.data.collections.new(f"FOSSEE_Cubes_{Operator_1.collection_counter}")

               # Linking/appending the new collection to the current scene's master collection i.e., the 'Scene Collection' menu
               context.scene.collection.children.link(self.new_collection)       

               # Creating cubes on X axis:
               for i in range(N - (N//2)):

                    # Creating a new mesh data block for the cube:
                    # A mesh is a data block which stores static geometry data without transforms.
                    mesh = bpy.data.meshes.new(name=f"Distributed_Cube_x_{i+1}_Collection_{Operator_1.collection_counter}")

                    # Creating a new object and assign the mesh to it:
                    #    -  An object is a container that holds the geometric data and defines its transform properties.
                    #         - Transform properties - These define where and how the object is positioned in 3D space.
                    
                    cube = bpy.data.objects.new(f"Distributed_Cube_x_{i+1}_Collection_{Operator_1.collection_counter}", mesh)
                    
                    # Object `cube` now references the `mesh` data block.  
                    
                    # Creating a cube in bmesh to generate the cube geometry:
                    #    - A bmesh is a dynamic mesh structure for complex editing.
                    bm = bmesh.new()     

                    # Creating a cube with the specified size in bmesh
                    bmesh.ops.create_cube(bm, size=cube_size)    # BMesh now holds cube geometry (vertices, edges, faces)

                    # Writing the bmesh data into the mesh data block:
                    bm.to_mesh(mesh)     # Geometry flows from `bm` → `mesh`

                    # Free the bmesh to avoid memory leaks
                    bm.free()    #BMesh is deleted (no longer needed)
                    
                    # Positioning the cube:
                    cube.location = (cursor_location.x + i, cursor_location.y, cursor_location.z)

                    # Add the cube to the newly created collection
                    self.new_collection.objects.link(cube)

               # Creating cubes on Y axis:
               for j in range(N // 2):

                    # Creating a new mesh data block for the cube:
                    # A mesh is a data block which stores static geometry data without transforms.
                    mesh = bpy.data.meshes.new(name=f"Distributed_Cube_y_{j+1}_Collection_{Operator_1.collection_counter}")

                    # Creating a new object and assign the mesh to it:
                    #    -  An object is a container that holds the geometric data and defines its transform properties.
                    #         - Transform properties - These define where and how the object is positioned in 3D space.

                    cube = bpy.data.objects.new(f"Distributed_Cube_y_{j+1}_Collection_{Operator_1.collection_counter}", mesh)
                    
                    # Object `cube` now references the `mesh` data block.  
                    
                    # Creating a cube in bmesh to generate the cube geometry:
                    #    - A bmesh is a dynamic mesh structure for complex editing.
                    bm = bmesh.new()     

                    # Creating a cube with the specified size in bmesh
                    bmesh.ops.create_cube(bm, size=cube_size)    # BMesh now holds cube geometry (vertices, edges, faces)

                    # Writing the bmesh data into the mesh data block:
                    bm.to_mesh(mesh)     # Geometry flows from `bm` → `mesh`

                    # Free the bmesh to avoid memory leaks
                    bm.free()    #BMesh is deleted (no longer needed)
                    
                    # Positioning the cube:
                    cube.location = (cursor_location.x, cursor_location.y + j + 1, cursor_location.z)

                    # Add the cube to the newly created collection
                    self.new_collection.objects.link(cube)

               # Resolving the overlaps (if any) present:
               self.resolve_overlaps(context)
               # Displaying a confirmation message in Blender's info log:
               self.report({'INFO'}, f"Created {N} cubes in collection '{self.new_collection.name}'")

               return {'FINISHED'}
     

     """
     The invoke() method is called when the operator is triggered (e.g., button click)
          - It handles initial execution and can show interactive elements before running execute()
             - context: Blender's runtime context (contains scene data, selected objects etc.)
             - event: Information about how the operator was triggered (mouse position etc.)
     """
     def invoke(self, context,event):
          settings = context.scene.my_addon_settings   
          # Accessing the addon's custom properties from the current scene
          
          # Validation check:
          if settings.input_n < 0:
               
               # Showing custom error popup with formatted message:
               bpy.ops.object.show_error_popup(
                    'INVOKE_DEFAULT',   #'INVOKE_DEFAULT' means show immediately with default settings
                    message=f"Value too small: {settings.input_n}. 'N' must be a natural number between 0-20."
               )
               return {'CANCELLED'}     # Aborting the operation    
               
          if settings.input_n > 20:
               bpy.ops.object.show_error_popup(
                    'INVOKE_DEFAULT',
                    message=f"Value too large: {settings.input_n}. 'N' must be a natural number between 0-20."
               )
               return {'CANCELLED'}

          return self.execute(context) # Calls the execute() method of the same class (Operator_1)
     

     """
     Creating a function "resolve_overlaps()" that checks if there is any overlap (using check_overlap() function) betweeen the cubes 
     of the newly created collection with any previously created collection.
     If the distance between the centers of two cubes from different collections is less than √3*cube_length, then all cubes 
     in the newly created collection are moved upward by 1 Blender unit. This condition is checked again to ensure that the cubes in the collection no longer overlap.
     We choose √3*cube_length because it is the distance between two spheres touching each other, where each sphere is circumscribing their respective cubes.
     """

     # A function that will check if there is any overlap between the created cubes.
     def check_overlap(self, cube1, cube2, cube_length=1.0):
          # Checking if cubes overlap based on center distance
          distance = (cube1.location - cube2.location).length
          return distance < (3**0.5) * cube_length  # sqrt(3)*cube_length

     # A function that will move the overlapping cubes by 1 Blender unit along the z-axis.    
     def resolve_overlaps(self, context, cube_length=1.0):
          # Move overlapping collections upward in 1-unit increments

          all_collections = context.scene.collection.children              # Accessing all the collections of cubes that I had made.
          current_idx = all_collections.find(self.new_collection.name)     # Accessing the index of the newly created collection
          
          if current_idx <= 0:     # If there are no preceding collections
               return False
          
          num_moved = 0    # The number of times the collection of cubes was moved up.
          moved = False
          max_attempts = 100     # To ensure that an infinte loop is not created we will be using this variable as a caveat.

          for attempt in range(max_attempts):

               needs_move = False       # Checker that we will use to check if we need to move the cubes or not using the method resolve_overlaps()

               # Checking the overlap with all preceding collections of cubes:
               for prev_col in all_collections[:current_idx]:
                    if prev_col.name.startswith("FOSSEE"):
                         for new_cube in self.new_collection.objects:
                              for prev_cube in prev_col.objects:
                                   if self.check_overlap(new_cube,prev_cube):
                                        needs_move = True
                                        num_moved+=1
                                        break     # If there is an overlap then we need to stop checking for it but start moving all the cubes instead.
                              if needs_move: 
                                   break
                         if needs_move:
                              break
                    
               if not needs_move: 
                    break          # If there is no overlap between the cubes for the current arrangement then we don't need to check it again


               # Move entire new collection up
               for cube in self.new_collection.objects:
                    cube.location.z+=1.0
               moved = True

          # Showing a popup if the cubes are moved
          if moved:
               # Showing custom error popup with formatted message:
               bpy.ops.object.show_overlapp_error_popup(
                    'INVOKE_DEFAULT',   #'INVOKE_DEFAULT' means show immediately with default settings
                    message=f"To avoid any possibility of overlap of cubes the object was moved up along the Z-axis by {num_moved} Blender units."
               )  
          return moved
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
I created an operator class 'Operator_2' which will perform deletion of the cubes selected by the user
"""
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
class Operator_2(bpy.types.Operator):

     # Defining a unique ID for the class
     bl_idname ="object.operator_2"
     """This means that the operator can be called in Blender
     via: bpy.ops.object.operator_2()"""

     # Writing a human readable label:
     bl_label = "Delete"

     # Defining the operator behavior:
     bl_options = {'UNDO'}
     # 'UNDO' allows users to undo the operator's action with Ctrl+Z

     # Writing a description for the operator:
     bl_description = 'Click to delete the selected cubes.'

     def execute(self,context):
          # Getting all selected objects:
          selected_objects = bpy.context.selected_objects

          if not selected_objects:
               self.report({'WARNING'}, "No mesh is selected")
               return{'CANCELLED'}
          
          # Delete the selected cubes:
          bpy.ops.object.delete()

          self.report({'INFO'}, f"Deleted {len(selected_objects)} object(s)")
          return{'FINISHED'}
     
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
 I created an operator class "Operator_3" which will help in merging the selected cubes. 
 It will merge the selected cube meshes into a single mesh while removing internal faces.
"""
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
class Operator_3(bpy.types.Operator):   # Inheriting from the bpy.types.Operator to create a custom Blender operator

     bl_idname = "object.operator_3"    # Defining a unique identifier for the operator
     bl_label = "Merge"                 # Displaying the name in the UI
     bl_options = {'UNDO'}              # Allows undoing of the operation
     bl_description = "Click to merge the selected meshes/cubes"
     
     def execute(self, context):        # The execute method runs automatically (if invoke method is not present) when the operator is triggered using the panel.

          # Accessing the selected cube meshes
          cubes = [obj for obj in context.selected_objects]

          # Telling the user to select at least 2 cubes if the user did not.
          if len(cubes) < 2:
               self.report({'ERROR'}, "Select at least 2 cubes")
               return {'CANCELLED'}
          
          # Sorting the cubes by their position in the coordinate system to ensure proper merging order (say left to right)
          cubes.sort(key=lambda x: (x.location.x, x.location.y, x.location.z))
          """
          The sort() method orders the list cubes in place.
          The 'key' parameter defines how objects are compared during sorting. Here, it uses a lambda function. 
          'x' represents a single cube from the cubes list.
          Here the lambda function returns the coordiantes of the cubes. Hence the cubes will be sorted in a uniform order.
          In other words the cubes are arranged in the consecutive order of their position.
          """

          # Computing the average location of the original cubes. We are doing this in order to center the merged mesh.
          avg_location = sum((obj.location for obj in cubes), Vector()) / len(cubes)
          """
          "Vector()" is a starting value for the sum (an empty vector (0.0,0.0,0.0))
          This will ensure that the sum starts form zero vector, avoiding errors when adding the first cube's location.      

          Blender's Vector class supports element-wise arithmetic (e.g., adding two vectors adds their XYZ components). 
          Without Vector(), sum() would treat the first obj.location as the starting value (e.g., a vector like (1, 0, 0)), 
          leading to incorrect results when adding subsequent vectors.
          """
          # Create main BMesh
          combined_bm = bmesh.new()     # Creating an empty BMesh to hold the merged geometry

          vert_map = {}                 
          """
          # vert_map is a dictionary that will map original vertices to new ones in combined_bm. 
          # It is a dictionary mapping original vertices to their copies in combined_bm.
          # This dictionary will be used later for reconstructing faces in combined_bm using the new vertices.
          Without it, I'd lose the track of which vertices belong to which cube, making it impossible to:
               - Correctly rebuild faces.
               - Remove internal/duplicate geometry later.

               Structure:
                    vert_map = {
                                   (source_object, original_vertex_index): new_vertex_in_combined_bm,
                                   ...
                                   }
                                        Key: A tuple (obj, v.index) identifying the original vertex (by its object and index).
                                        Value: The new BMVert created in combined_bm.
          """

          # Checking if all the cubes are connected using a function cubes_connected() which is defined below execute()

          if not self.cubes_connected(cubes):
               self.report({"ERROR"},"Not all of the meshes/cubes share common faces.")
               return{'CANCELLED'}

          # We will be comining multiple individual BMeshes (from each cube) into a single merged BMesh.

          # We will essentially access the data for the vertices and faces of each cube using BMesh and then pass this information to the combined mesh.
          for obj in cubes:

               # Creating a temporary BMesh  
               bm = bmesh.new()

               # Loading the cube's mesh data into the BMesh
               bm.from_mesh(obj.data)

               # Applying world transformation for converting to world coordinates
               bm.transform(obj.matrix_world)  # This ensures that all cubes are in the same coordinate system before merging

               # Adjust vertices to be relative to the average location
               for v in bm.verts:
                    v.co -= avg_location  # Make coordinates relative to avg_location
               
               # Ensuring that we can access vertices/faces by index
               bm.verts.ensure_lookup_table()
               bm.faces.ensure_lookup_table()
               """
                    ensure_lookup_table():   BMesh does not maintain vertex/face indexing by default for performance reasons.
                                             - This function rebuilds internal lookup tables, allowing access to elements by index.
                    One must call it after adding/removing geometry (vertics, faces, edges) and before performing operations that require index-based access.
               
                    ===> Since BMesh in Blender doesn’t maintain an internal index-based lookup table by default (for performance reasons), I must explicitly call
                    them as I need index-based access to vertices or faces (e.g., bm.verts[i] or bm.faces[j])
               """

               # Adding vertices to combined BMesh
               for v in bm.verts:                               # Iterating through all vertices of the current cube's BMesh
                    new_vert = combined_bm.verts.new(v.co)      # Creating a new vertex in the combined BMesh with the same coordinates.
                                                                # v.co contains the already transformed and centered coordinates

                    vert_map[(obj, v.index)] = new_vert         # Mapping the original vertex to the new vertex in vert_map dictionary

               # Adding faces using the vertex map
               for f in bm.faces:                               # Iterating through all faces of the current cube's BMesh
                    combined_bm.faces.new([vert_map[(obj, v.index)] for v in f.verts])
                    """
                    Creating a new face in the combined mesh by:
                         - Accesing the vertices in the orignal face
                         - Using 'vert_map' dictionary to find the corresponding new vertices in combined_bm
                    """
               bm.free()      # Each temporary BMesh is being freed after processing. Only combined_bm remains.

          # Update the combined BMesh
          combined_bm.verts.ensure_lookup_table()
          combined_bm.faces.ensure_lookup_table()
          """
               ensure_lookup_table():   BMesh does not maintain vertex/face indexing by default for performance reasons.
                                        - This function rebuilds internal lookup tables, allowing access to elements by index.
               One must call it after adding/removing geometry (vertics, faces, edges) and before performing operations that require index-based access.
          """


          """
          This section of the code will identify and remove internal/redundant faces from the merged geometry:
          
          Finding and removing face pairs that:
          1. Have opposite normals (dot product of normals ≈ -1). # This will prevent deletion of perpendicular faces
          2. Are coincident (same center position) that is the distance between the centers of the faces is ~ 0.

          As a fact, for a standard axis-aligned cube:
               there are three pairs of opposing faces, each pair having normals that point in exactly opposite directions (dot product = -1).
          """

          face_delete_set = set()                          # Creating an empty set for storing faces marked for deletion
          faces = list(combined_bm.faces)                  # Accessing the face collection of the combined_bm and store it in a list
          for i, face in enumerate(faces):        
               if face in face_delete_set:
                    continue                                # Skipping the faces that are already marked to be deleted.
               face_center = face.calc_center_median()      # Calculating the grometric center of the face
               for other_face in faces[i+1:]:     # Checking with the subsequent faces
                    if other_face in face_delete_set:
                         continue
                    if (face_center - other_face.calc_center_median()).length >0.01:
                         continue
                    """
                    This catches only overlapping internal faces while ignoring:
                    - Faces that happen to oppose but aren't touching (far apart)
                    - Faces that overlap but aren't opposites (like perpendicular walls)
                    """
                    face_delete_set.add(face)
                    face_delete_set.add(other_face)
                    break     # Stop after finding the first pair

          if face_delete_set:
                    if len(face_delete_set) < 2*(len(cubes)-1):
                         self.report({'ERROR'}, "The selected cubes does not have a consecutive common face.")
                         return {'CANCELLED'}
                    
                    # Deleting all redundant/internal faces stored in the face_delete_set.
                    bmesh.ops.delete(combined_bm, geom=list(face_delete_set), context='FACES')      
          bmesh.ops.remove_doubles(combined_bm, verts=combined_bm.verts, dist=0.0001) 
          """
          bmesh.ops.remove_doubles(combined_bm, verts=combined_bm.verts, dist=0.0001)
               When this operation runs:
               It will search for any vertices that are within 0.0001 units of each other
               For each group of vertices that are closer than this distance, it will merge them into a single vertex
               All edges and faces connected to the removed vertices will be reconnected to the remaining vertex
          """

          # Creating the merged object and set its location to the average:


          # Creating a new empty mesh datablock named "Merged_Cuboid". This isn't yet an object in the scene.
          merged_mesh = bpy.data.meshes.new("Merged_Cuboid")          

          # Converting the BMesh to a Blender mesh (copying all vertices, edges, and faces)
          combined_bm.to_mesh(merged_mesh)

          # Creating a new object using the mesh data
          merged_obj = bpy.data.objects.new("Merged_Cuboid", merged_mesh)

          # Positioning at the average location
          merged_obj.location = avg_location  

          # Link to the scene:
          context.collection.objects.link(merged_obj)
          
          # Making the new object active and selecting it
          bpy.context.view_layer.objects.active = merged_obj
          merged_obj.select_set(True)

          # Removing the old cubes:
          for obj in cubes:
               bpy.data.objects.remove(obj, do_unlink=True)
          
          combined_bm.free()  # Freeing the BMesh

          self.report({'INFO'}, f"Merged {len(cubes)} cubes.")
          return {'FINISHED'}

     # Creating a function that will check if the cubes are connected:

     def cubes_connected(self,cubes):

          if not cubes:
               return False
          
          connected_pairs = set()    # To collect all the unique pairs of cubes that are connected to each other


          # Finding all unique pairs that are connected:

          for i, cube_1 in enumerate(cubes):

               # Creating a temporary BMesh  
               bm1 = bmesh.new()

               # Loading the cube's mesh data into the BMesh
               bm1.from_mesh(cube_1.data)

               # Applying world transformation for converting to world coordinates
               bm1.transform(cube_1.matrix_world)

               for cube_2 in cubes[i+1:]:

                    # Creating a temporary BMesh 
                    bm2 = bmesh.new()

                    # Loading the cube's mesh data into the BMesh
                    bm2.from_mesh(cube_2.data)

                    # Applying world transformation for converting to world coordinates
                    bm2.transform(cube_2.matrix_world)

                    # Considering all face combinations:
                    for f1 in bm1.faces:
                         for f2 in bm2.faces:
                              if((f1.calc_center_median()-f2.calc_center_median()).length < 0.01):
                                   connected_pairs.add(frozenset({cube_1,cube_2}))
                                   break

                    bm2.free()
               bm1.free()

          # Building connection graph to determine if all cubes form a single connected network by modelling thier relationships as a graph and traversing it.
          graph = {cube:set() for cube in cubes}
          # Creating a dictionary - 'graph' that has each cube object as its 'key' and sets of cubes that directly touch the 'key' cube as its key-value.
          

          # For each detected face connection between two cubes ('connected_pairs' set) adding each cube to the other's connection set
          for pair in connected_pairs:
               cube_1,cube_2 = pair
               graph[cube_1].add(cube_2)
               graph[cube_2].add(cube_1)

          # Checking full connectivity

          visited = set()      # A set to track the cubes I have processed
          queue = [cubes[0]]   # Starting with the first cube (arbitrary starting point). 'queue' is a list

          while queue:
               current = queue.pop()                             # Get next cube to process
               if current not in visited:                        # Taking the cube as 'current' from the queue
                    visited.add(current)                         # If the cube is not already visited then marking it as processed...
                    queue.extend(graph[current]-visited)         # ... and adding all its unvisited neighbours to the queue by subtracting 2 sets.

          return len(visited)==len(cubes)                        # True if all cubes are connected, false otherwise

#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
"""
     I created a new panel by subclassing bpy.types.Panel, this tells Blender that I am defining a new UI panel.
"""
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
class Panel_1(bpy.types.Panel):
    
     #The visible title of the panel:
     bl_label = "FOSSEE_ADDON "            

     # Unique identifier for the panel:
     bl_idname = "ID_Panel_1"        

     # The panel will appear in the 3D Viewport:
     bl_space_type = "VIEW_3D"       

     # The panel will appear in the UI side/region:
     bl_region_type = "UI"           

     # The name of the tab in the sidebar where the panel will be placed:
     bl_category = "Build_Mesh_Addon"           


     # The draw method defines the UI elements:
     def draw(self,context):
          
          # Get the layout manager of the panel:
          layout = self.layout

          # Get the Addon's properties
          settings = context.scene.my_addon_settings

          """Creating an input field with label and range:"""

          # Create a box container to group related settings
          box = layout.box()

          # Create a horizontal row within the box
          row = box.row()

          # Add a label to the box as a heading
          row.label(text = 'Distributing cubes around \'Cursor\'.',icon ="UV_VERTEXSEL")

     # Input field with range indicator
          row = box.row()
          """
          This line creates a property field that will automatically show as a slider 
          since the property input_n is defined as an IntProperty:
          """
          row.prop(settings, "input_n", text="Number of cubes (N) =")    # Basic syntax: row.prop(data, property_name, **kwargs)

          # New row for buttons:
          row = box.row()
          
          # Execution button:
          row.operator("object.operator_1")    

          # Deleting the selected cubes:
          row.operator("object.operator_2",icon='TRASH')

          row = layout.row()
          row.operator("object.operator_3",icon="AUTOMERGE_ON")
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------    
"""
The register function is called when enabling the addon.
It is used to register classes and setup resources.

NOTE: bpy.utils handles registration of add-ons, custom classes and system paths.
"""

def register():
    bpy.utils.register_class(MyAddonSettings)

    """Creating a new property called 'my_addon_settings' on Blender's Scene type which will be a pointer to an instance
    of 'MyAddonSettings', which is a class that inherits from bpy.types.propertyGroup
    
    We do this because MyAddonSettings doesn't have a 'Scene' attribute.
    One more reason to do this is to avoid conflicts between 2 addons that might accidentally use the same variable name 'e.g., scene.settings'."""
    bpy.types.Scene.my_addon_settings = bpy.props.PointerProperty(type=MyAddonSettings)
    # This creates a property my_addon_settings on every Blender Scene.

    bpy.utils.register_class(ShowError)
    bpy.utils.register_class(Show_Overlapp_Error)
    bpy.utils.register_class(Operator_1)
    bpy.utils.register_class(Operator_2)
    bpy.utils.register_class(Operator_3)
    bpy.utils.register_class(Panel_1)

"""
The unregister function is called when disabling the addon.
It cleans up what was regstered
"""
def unregister():
    bpy.utils.unregister_class(Panel_1)
    bpy.utils.unregister_class(Operator_1)
    bpy.utils.unregister_class(Operator_2)
    bpy.utils.unregister_class(Operator_3)
    bpy.utils.unregister_class(ShowError)
    bpy.utils.unregister_class(Show_Overlapp_Error)
    del bpy.utils.types.Scene.my_addon_settings
    bpy.utils.unregister_class(MyAddonSettings)
        
        
"""This allows the script to be run directly (for testing)"""        
if __name__ == "__main__":
        register()
#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------